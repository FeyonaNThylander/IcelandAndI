﻿define("epi-languagemanager/request/LanguageManagerContentLanguage", [
    "dojo/Deferred"
], function (Deferred) {

    return {
        beforeSend: function (params) {
            // summary:
            //      Request mutator for adding the currently selected content language to a xhr request
            //      By the default, the [project-item] store always use current language (ContentLanguage.PreferredCulture),
            //      This module will chain the request and change the header key "x-EPiContentLanguage" with our custom language id.
            // params: Object
            //      The request parameters
            // tags: internal

            var options = params.options;
            if (options.postData) {
                var data;
                try {
                    data = JSON.parse(options.postData);
                } catch (e) { /*quiet*/ }

                if (data && data.modifyHeader === true && data.LanguageID) {
                    options.headers["X-EPiContentLanguage"] = data.LanguageID;
                }
            }

            var result = new Deferred();
            result.resolve(params);

            return result.promise;
        }
    };

});
