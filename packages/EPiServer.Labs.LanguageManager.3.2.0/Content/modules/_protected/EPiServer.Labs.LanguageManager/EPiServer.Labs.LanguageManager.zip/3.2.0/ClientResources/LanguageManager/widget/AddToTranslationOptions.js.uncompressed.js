require({cache:{
'url:epi-languagemanager/widget/templates/AddToTranslationOptions.html':"﻿<section class=\"epi-languageManager-optionsSelector\">\n    <div class=\"epi-languageManager__notificationBar\" data-dojo-attach-point=\"notificationBar\">\n        <span class=\"media-list__object dijitInline dijitReset dijitIcon epi-icon--large epi-icon--colored epi-iconWarning epi-floatLeft\"></span>\n        <label class=\"epi-languageManager__notificationMessage\" data-dojo-attach-point=\"notificationMessage\"></label>\n    </div>\n    <ul class=\"option-list\">\n        <li class=\"option-list-item\">\n            <label data-dojo-attach-point=\"projectSelectorLabel\">${res.options.addtoproject}</label>\n            <span data-dojo-type=\"epi-cms/project/ProjectSelector\" data-dojo-attach-point=\"projectSelector\"></span>\n        </li>\n        <li class=\"option-list-item\">\n            <input data-dojo-attach-point=\"addAllChildrenOption\" id=\"option-addAllChildren\" type=\"checkbox\" />\n            <label for=\"option-addAllChildren\">${res.options.addallchildren}</label>\n        </li>\n        <li class=\"option-list-item\">\n            <input data-dojo-attach-point=\"addRelatedBlocksOption\" id=\"option-addRelatedBlocks\" type=\"checkbox\" />\n            <label for=\"option-addRelatedBlocks\">${res.options.addrelatedblocks}</label>\n        </li>\n    </ul>\n</section>"}});
﻿define("epi-languagemanager/widget/AddToTranslationOptions", [
// dojo
    "dojo/_base/declare",
    "dojo/dom-style",
    "dojo/html",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    // epi
    "epi/dependency",
    "epi/shell/widget/dialog/_DialogContentMixin",
    "epi-cms/project/ProjectSelector",
    // template
    "dojo/text!./templates/AddToTranslationOptions.html",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.addtoproject"
],
function (
// dojo
    declare,
    domStyle,
    html,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    // epi
    dependency,
    _DialogContentMixin,
    ProjectSelector, // used in template
    // template
    template,
    // resources
    resources
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _DialogContentMixin], {

        templateString: template,

        res: resources,

        // projectStore: [readonly] Store
        //      A REST store for interacting with projects.
        projectStore: null,

        postscript: function () {

            this.inherited(arguments);

            this.projectStore = this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");
        },

        startup: function () {

            this.inherited(arguments);

            var projectSelector = this.projectSelector;

            projectSelector.set("store", this.projectStore);
        },

        showNotification: function (/*String*/message) {
            // summary:
            //      Show notification
            // message: [String]
            //      Notification message to show
            // tags:
            //      public

            html.set(this.notificationMessage, message);

            domStyle.set(this.notificationBar, { display: "block" });
        },

        hideNotification: function () {
            // summary:
            //      Hide notification
            // tags:
            //      public

            domStyle.set(this.notificationBar, { display: "none" });
        }

    });

});
