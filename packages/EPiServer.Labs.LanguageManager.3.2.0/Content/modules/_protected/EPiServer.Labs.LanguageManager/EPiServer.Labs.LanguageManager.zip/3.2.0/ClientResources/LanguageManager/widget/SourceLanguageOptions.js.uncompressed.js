require({cache:{
'url:epi-languagemanager/widget/templates/SourceLanguageOptions.html':"﻿<section class=\"epi-languageManager-optionsSelector\">\n    <ul data-dojo-attach-point=\"languagesNode\" class=\"option-list\">       \n    </ul>\n</section>"}});
﻿define("epi-languagemanager/widget/SourceLanguageOptions", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-construct",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    // epi
    "epi/shell/widget/dialog/_DialogContentMixin",
    //epi-languagemanager
    "./LanguageOption",
    // template
    "dojo/text!./templates/SourceLanguageOptions.html",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.addtoproject"
],
function (
// dojo
    declare,
    lang,
    array,
    domConstruct,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    // epi
    _DialogContentMixin,
    //epi-languagemanager
    LanguageOption,
    // template
    template
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _DialogContentMixin], {
        templateString: template,

        postCreate: function () {
            this.inherited(arguments);

            this.renderListOptions();
        },

        renderListOptions: function () {
            if (!this.languageBranches || !this.languageBranches.length) {
                return;
            }

            array.forEach(this.languageBranches, function (item) {
                var itemSetting = null;
                this.own(
                    itemSetting = new LanguageOption({ item: item }),
                    this.connect(itemSetting, "onChange", lang.hitch(this, function (item, selected) {
                        if (selected) {
                            this.selectedLanguage = item;
                            this.onChange(this.selectedLanguage);
                        }
                    }))
                );
                domConstruct.place(itemSetting.domNode, this.languagesNode, "last");
            }, this);
        },

        onChange: function () {

        }
    });
});
